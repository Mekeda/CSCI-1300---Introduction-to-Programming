"""
Assignment Name: Assignment 7 Ciphers - chipher.py

Authors: John Richards and Spencer Milbrandt

Description: This program will give the user the choice to encrypt or decrypt 
a file using two different methods. The two meathods are a Caesar Cipher and
a deranged cipher.

Date: 10/11/13
Version 1
"""

# this imports several strings of characters that are useful
#	for solving these problems
# print them out to see what they contain
from string import ascii_uppercase as letters
from string import punctuation as symbols
from string import digits
from string import whitespace

def caesar_cipher(text, key):
	"""
	Encrypts or Decrypts text using a Caesar cipher with the
	 supplied key value
	Params - text to modify and the key value
	Return - the text modifed by the Caesar cipher
	
	"""
	'''
	Algorithm:
	Remove digits, special characters, and whitespace from the text
	Convert the text to uppercase
	Get the caesar cipher dictionary codec
	Convert each of the text characters and put them into a list
	Return the string of the list contents (e.g., ['a', 'b', 'c'] would become 'abc')
	'''
	
	text = remove_digit_chars(text)
	text = remove_symbol_chars(text)
	text = remove_whitespace_chars(text)
	text = text.upper()
	codec = create_caesar_codec(key)
	message = ""
	for l in range(len(text)):
		message = message + codec[text[l]]
		
	# modify this return to send back correct value
	return message
		
def deranged_cipher(text, keyword, toEncrypt):
	"""
	Encrypts or Decrypts text using a deranged alphabet cipher with the
	 supplied secret keyword/phrase.
	Params - text to modify, the keyword cipher text, and whether to encrypt
	Return - the text modifed by the deranged cipher
	"""
	
	'''
	Algorithm:
	similar to Caesar cipher except for getting the deranged dictionary codec
	'''
	text = remove_digit_chars(text)
	text = remove_symbol_chars(text)
	text = remove_whitespace_chars(text)
	text = text.upper()
	codec = create_deranged_codec(keyword, toEncrypt)
	message = ""
	for l in range(len(text)):
		message = message + codec[text[l]]
		
	# modify this return to send back correct value
	return message

def remove_duplicate_chars(line):
	"""
	Leaves first occurrence of a character in a string and
	  removes all duplicates of that character
	  e.g., the string 'abcba' becomes 'abc'
			the string 'a b c b a' becomes 'a bc'
	Params - line of text to modify
	Return - the modified string
	"""
	
	# this is provided for you, no changes needed
	
	chars = []
	
	for c in line:
		if chars.count(c) < 1:
			chars.append(c)
			
	return "".join(chars)
	
def remove_symbol_chars(line):
	"""
	Removes all punctuation characters in a string
	  e.g., the string '-!00!-' becomes '00'
	Params - line of text to modify
	Return - the modified string
	"""
	
	'''
	You will want to use the string replace method
	'''
	for char in "?.,!/;:-~`#&":
		line = line.replace(char, "")
	
	return line
	
def remove_whitespace_chars(line):
	"""
	Removes all whitespace characters in a string
	  e.g., the string '  a b c  b    a' becomes 'abcba'
	Params - line of text to modify
	Return - the modified string
	"""
	
	'''
	You will want to use the string replace method
	'''
	
	for char in " \t \n":
		line = line.replace(char, "")
	
	return line
	
def remove_digit_chars(line):
	"""
	Removes all digit characters in a string
	  e.g., the string '10dollars10' becomes 'dollars'
	Params - line of text to modify
	Return - the modified string
	"""
	
	'''
	You will want to use the string replace method
	'''
	numbers = ["0","1","2","3","4","5","6","7","8","9"] 
	for char in numbers:
		line = line.replace(char, "")
	
	return line

def create_caesar_codec(key):
	"""
	Creates a dictionary that maps a normal character to the
	 coded character value after using a caesar cipher
	Params - the key value, which is an integer
	  a positive key shifts forward and negative backward
	Return - the dictionary codec
	"""
	
	codec = {}
	
	# this fixes a key value out of the range -26 to 26
	key = key % 26
		
	for c in letters:
		chrNum = ord(c) + key
	
		''' Complete this area '''
		# if chrNum is less than 65 or over 90, chrNum needs to wrap around
		#  so that the converted number will produce something in 'A' - 'Z'
		# e.g., 91 would become 65, 92 would become 66
		#		64 would become 90, 63 would become 89
		# This conversion process only requires some math to complete
		if chrNum > 90:
			chrNum = chrNum - 26
		elif chrNum < 65:
			chrNum = chrNum + 26
			
		codec[c] = chr(chrNum)
		
	return codec
	
def create_deranged_codec(keyword, toEncrypt):
	"""
	Creates a dictionary that maps a normal character to the
	 encoded character value after using a deranged cipher
	Params - the key value, which is an integer
	  a positive key shifts forward and negative backward
	Return - the dictionary codec
	"""
	codec = {} 
	
	'''
	Algorithm:
	Cleanup the secret text by removing special characters, digits
	  and whitespace
	Make keyword text all uppercase
	Make a string that contains the secret text followed by the
	  uppercase alphabet (A through Z)
	Remove the duplicates in this new string
	Based on value of toEncrypt, add values to dictionary for encryption or
	  decryption. The dictionary keys and values are swapped
	  depending whether it is encryption or decryption. 
	'''
	keyword = keyword.upper()
	keyword = remove_whitespace_chars(keyword)
	keyword = remove_digit_chars(keyword)
	keyword = remove_symbol_chars(keyword)
	alphaKey = keyword
	for i in letters:
		alphaKey = alphaKey + i
	alphaKey = remove_duplicate_chars(alphaKey)
	if(toEncrypt == True):
		for c in letters:
			key = ord(c) - 65
			ch = alphaKey[key]
			codec[c] = ch
	else:
		for c in letters:
			codec[alphaKey[ord(c)-65]] = c
		
	return codec 
	
def print_cipher_codec(codec):
	"""
	This prints out the contents in the dictionary. It isn't 
	 actually specific to just printing a codec and could
	 print out any dictionary supplied.
	
	Params - The dictionary cipher codec
	Return - None
	"""
	
	print("\nCipher Codec Contents:")
	
	for c in letters:
		print("key = {} has value = {}".format(c, codec[c]))
	
	print()
	
def main():
	# you can use the main function for testing and trying out
	#  various things that were left here
	
	nums = "888 dollars 888"
	print(remove_digit_chars(nums))
	
	msg = "Hail Caesar!"
	
	txt = 'a' * 4 + 'b' * 2 + 'c'
	
	txt = remove_duplicate_chars(txt)
	
	print(txt)
	
	key = -2
	emsg = caesar_cipher(msg, key)
	print(msg)
	print(emsg)
	dmsg = caesar_cipher(emsg, -key)
	print(dmsg)
	print()
	
	secret = "..jazz jackrabbit	/?ghijklmnopqrstuvwxyz324"
	msg2 = "The quick brown fox"
	emsg = deranged_cipher(msg2, secret, True)
	print(emsg)
	dmsg = deranged_cipher(emsg, secret, False)
	print(dmsg)
	
	# when the codec creation is working, you can uncomment this
	#  to see the deranged codec values
	#myCodec = create_deranged_codec(secret, True)
	#print_cipher_codec(myCodec)
	
	
	
	ws_tests = ["\t\t   ab c  d b		a", ".", "\t", ""]
	
	symbol_tests = ["-!!~~oo~~!!-", "#", "a", "bab", "\t", ""]
	
	dup_tests = [".A B A C B A.", ".", "a", "cba", "\ta\tb", ""]
	
	for i in range(len(ws_tests)):
		result = remove_whitespace_chars(ws_tests[i])
		print("WS Test {} result: {}".format(i + 1, result))
	print()
	
	for i in range(len(symbol_tests)):
		result = remove_symbol_chars(symbol_tests[i])
		print("Sym Test {} result: {}".format(i + 1, result))
	print()
			
	for i in range(len(dup_tests)):
		result = remove_duplicate_chars(dup_tests[i])
		print("Dup Test {} result: {}".format(i + 1, result))
	print()
	
	codec = create_caesar_codec(2)
	print(codec)
	
	values = codec.values()
	
	for c in letters:
		print("codec[{}] = {}".format(c, codec[c]))
		
	print(len(codec))
	
	rcodec = create_caesar_codec(-2)
	
	for c in letters:
		print("rcodec[{}] = {}".format(c, rcodec[c]))
	
	dcodec = create_deranged_codec("happy joy...to the world", True)
	print(dcodec)
	
	for c in letters:
		print("dcodec[{}] = {}".format(c, dcodec[c]))
		
	rdcodec = create_deranged_codec("happy joy...to the world", False)
		
	for c in letters:
		print("rdcodec[{}] = {}".format(c, rdcodec[c]))
	
	
if __name__ == '__main__':
	main()
